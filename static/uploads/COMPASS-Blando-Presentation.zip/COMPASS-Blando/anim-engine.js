/* anim-engine.js — drives all per-slide animations and the menu/step system */
(() => {
  const deck = document.getElementById('deck');
  const menuOverlay = document.getElementById('menuOverlay');
  const menuTrigger = document.getElementById('menuTrigger');
  const mainMenu = document.getElementById('mainMenu');
  const qaMenu = document.getElementById('qaMenu');

  // ---------- helpers ----------
  const slides = Array.from(deck.children);
  const MAIN_COUNT = 22;
  const slideDescriptions = [
    "Cover · Title and authorship",
    "Agenda · Three acts and one question",
    "Problem · Crises share a signature; VIX is contemporaneous",
    "Idea · Markets as graphs · 173 topology features",
    "Dataset · 210 S&P 500 stocks over 12.5 years",
    "Network animation · Calm 2019 vs COVID-19 March 2020",
    "Absorption Ratio · variance concentration over time",
    "ML pipeline · Boosting, LSTM, GraphSAGE, GAT",
    "Target Engineering · 40 definitions of market stress",
    "Ablation Study · the value of network features",
    "Lead-lag · Networks lead the market by 4.2 days",
    "SHAP · VIX dominates; sector centralities surprise",
    "Herding · Shocks herd, gradual declines do not",
    "Spillover · Industrials/Financials transmit",
    "Contagion · BFS cascade through the correlation graph",
    "Trading · Hysteresis, Kelly, ML+Trend hybrid",
    "Statistical Validation · performance beyond chance",
    "Headline · Sharpe 0.79 vs 0.46",
    "Future Directions · Methodological & asset expansion",
    "Conclusion · Leading, complementary, tradeable",
    "References · Key academic foundation",
    "Thank you · Q&A",
  ];
  const qaDescriptions = [
    "Methodology · walk-forward purged, formulas",
    "COVID-19 case study · numbers in detail",
    "Robustness · five layers of stress-testing",
    "Limitations · what this work does not claim",
  ];

  // build menu
  slideDescriptions.forEach((d, i) => {
    const [t, sub] = d.split(' · ');
    const el = document.createElement('button');
    el.className = 'menu-card';
    el.innerHTML = `<div class="num">${String(i+1).padStart(2,'0')}</div><div class="ttl">${t}</div><div class="desc">${sub || ''}</div>`;
    el.addEventListener('click', () => { 
      const active = deck.querySelector('section[data-active="true"]');
      if (active) active.classList.add('exiting');
      deck.goTo(i); 
      closeMenu(); 
    });
    mainMenu.appendChild(el);
  });
  qaMenu.innerHTML = '';
  qaDescriptions.forEach((d, i) => {
    const [t, sub] = d.split(' · ');
    const el = document.createElement('button');
    el.className = 'menu-card';
    el.innerHTML = `<div class="num">QA · ${String(i+1).padStart(2,'0')}</div><div class="ttl">${t}</div><div class="desc">${sub || ''}</div>`;
    el.addEventListener('click', () => { 
      const active = deck.querySelector('section[data-active="true"]');
      if (active) active.classList.add('exiting');
      deck.goTo(MAIN_COUNT + i); 
      closeMenu(); 
    });
    qaMenu.appendChild(el);
  });

  function openMenu() { 
    menuOverlay.classList.add('open'); 
    // stagger cards
    const cards = menuOverlay.querySelectorAll('.menu-card');
    cards.forEach((c, i) => {
      c.style.transitionDelay = `${i * 30}ms`;
    });
  }
  function closeMenu() { 
    menuOverlay.classList.remove('open'); 
    const cards = menuOverlay.querySelectorAll('.menu-card');
    cards.forEach((c) => {
      c.style.transitionDelay = '0ms';
    });
  }
  menuTrigger.addEventListener('click', () => {
    if (menuOverlay.classList.contains('open')) closeMenu();
    else openMenu();
  });

  // ---------- step system within slides ----------
  // Each slide's `.step` elements reveal in order with → / Space / click.
  // We track per-slide step index and consume the key event before deck-stage
  // advances when there are still steps left.
  const stepState = new WeakMap();
  function getSteps(slide) {
    return Array.from(slide.querySelectorAll('.step'));
  }
  function applyStepCount(slide, n) {
    // n is 1-based step count (e.g. n=1 means show Step 0)
    const allSteps = getSteps(slide);
    allSteps.forEach(el => {
      const stepIdx = parseInt(el.dataset.step || '0', 10);
      el.classList.toggle('is-on', stepIdx < n);
    });
    
    // Custom: Trigger network animation on Slide 06 when advancing past first step
    if (slide.dataset.label === 'Network anim') {
      if (n > 1) runNetworkAnim(1);
      else runNetworkAnim(0, 0); // instant reset to calm
    }

    // dot indicator
    const dots = slide.querySelector('.stepdots');
    if (dots) {
      const total = slide._stepCount || 0;
      dots.innerHTML = '';
      for (let i = 0; i < total; i++) {
        const d = document.createElement('i');
        if (i < n) d.classList.add('on');
        dots.appendChild(d);
      }
    }
  }

  // Auto-build step list: every direct meaningful child of a slide becomes a step.
  // We tag them at boot — so the user always reveals one element at a time on →,
  // like a vertical scroll site auto-revealing sections in order.
  function autoTagSteps() {
    slides.forEach((slide) => {
      const label = slide.dataset.label;
      const skip = ['Cover', 'Agenda', 'Thanks', 'Dataset'].includes(label) || (label && label.startsWith('QA ·'));
      
      // Clean up any existing step classes/states
      slide.querySelectorAll('.step').forEach(el => {
        el.classList.remove('step', 'is-on');
        delete el.dataset.step;
      });

      if (label === 'Network anim') {
        slide._stepCount = 2;
        // No need to tag elements, we handle this slide via n index
        return;
      }

      if (skip) {
        slide._stepCount = 1;
        // Ensure skip slides don't have hidden elements if they were tagged in HTML
        return;
      }

      // 1. Identify "Immediate" elements (Kickers, Titles, Stages, Hero stats)
      const immediateSelectors = [
        '.kicker', 'h1', 'h2', 'h3', '.eyebrow',
        'canvas', 'svg', 
        '[class*="-stage"]', 
        '[class*="-wrap"]',
        '.num-huge',
        '.hero-stat .left h2',
        '.crisis-timeline',
        '.timeline-h',
        '#netStats'
      ];
      
      const immediateElements = [];
      immediateSelectors.forEach(sel => {
        slide.querySelectorAll(sel).forEach(el => {
          if (!el.closest('.footer')) immediateElements.push(el);
        });
      });

      // 2. Identify "Sequential" elements
      const sequentialSelectors = [
        '.lead', '.quote', '.formula', 
        '.crisis-timeline', '.idea-col', '.ml-pipeline', 
        '.shap-stage', '.cck-table', '.mini-table', 
        '.conc-pillars', 'ul.clean', '.caption', '.stat',
        '.net-meta .stat', '.net-meta button', '.target-block', '.future-item'
      ];

      const sequentialElements = [];
      sequentialSelectors.forEach(sel => {
        slide.querySelectorAll(sel).forEach(el => {
          if (el.closest('.footer')) return;
          if (immediateElements.includes(el)) return;
          const containers = ['.crisis-timeline', '.ml-pipeline', '.shap-stage', '.cck-table', '.mini-table', '.conc-pillars', 'ul.clean', '.stat', '.heatmap-wrap', '.stat-row'];
          for (const c of containers) {
            const parent = el.parentElement.closest(c);
            if (parent && parent !== el) return;
          }
          sequentialElements.push(el);
        });
      });
      // catch paragraphs and lists even if nested
      slide.querySelectorAll('p, ul.clean, .stat, .idea-col, .ml-pipeline, .shap-stage, .cck-table, .mini-table, .conc-pillars, .caption, .future-item').forEach(el => {
        if (!el.closest('.footer') && !immediateElements.includes(el) && !sequentialElements.includes(el)) {
          // ensure it's not inside another step container to avoid double-tagging
          const containers = ['.idea-grid', '.ml-pipeline', '.shap-stage', '.cck-table', '.mini-table', '.conc-pillars', 'ul.clean', '.stat', '.heatmap-wrap', '.stat-row', '.future-grid', '.target-block'];
          let inside = false;
          for (const c of containers) {
            const parent = el.parentElement.closest(c);
            if (parent && parent !== el) { inside = true; break; }
          }
          if (!inside) sequentialElements.push(el);
        }
      });

      sequentialElements.sort((a, b) => {
        return a.compareDocumentPosition(b) & Node.DOCUMENT_POSITION_FOLLOWING ? -1 : 1;
      });

      // 3. Build the steps array
      const steps = [];
      if (immediateElements.length) steps.push(immediateElements);
      sequentialElements.forEach(el => steps.push([el]));

      // 4. Apply classes and data-step
      steps.forEach((group, i) => {
        group.forEach(el => {
          el.classList.add('step');
          el.dataset.step = i;
        });
      });

      slide._stepCount = steps.length;
    });
  }
  autoTagSteps();

  function resetSlide(slide) {
    // Reveal first step automatically
    stepState.set(slide, 1);
    applyStepCount(slide, 1);
  }
  function maxSteps(slide) {
    return slide._stepCount || 1;
  }

  // intercept keyboard nav before deck-stage acts
  window.addEventListener('keydown', (e) => {
    if (e.key === 'm' || e.key === 'M') {
      e.preventDefault(); e.stopPropagation();
      if (menuOverlay.classList.contains('open')) closeMenu();
      else openMenu();
      return;
    }
    if (menuOverlay.classList.contains('open')) {
      if (e.key === 'Escape') { closeMenu(); e.preventDefault(); e.stopPropagation(); }
      return;
    }
    const active = deck.querySelector('section[data-active="true"]');
    if (!active) return;
    if (e.key === 'ArrowRight' || e.key === ' ' || e.key === 'PageDown') {
      const cur = stepState.get(active) || 0;
      const total = maxSteps(active);
      if (cur < total) {
        stepState.set(active, cur + 1);
        applyStepCount(active, cur + 1);
        updateRail(slides.indexOf(active), active);
        e.preventDefault();
        e.stopPropagation();
      } else {
        // prepare exit for next slide
        active.classList.add('exiting');
      }
    } else if (e.key === 'ArrowLeft' || e.key === 'PageUp') {
      const cur = stepState.get(active) || 0;
      if (cur > 1) {
        stepState.set(active, cur - 1);
        applyStepCount(active, cur - 1);
        updateRail(slides.indexOf(active), active);
        e.preventDefault();
        e.stopPropagation();
      }
    }
  }, true); 

  // mark active slide for CSS targeting + reveal-all on first step
  let lastActive = null;
  const railFill = document.getElementById('scrollRailFill');
  const railLabel = document.getElementById('scrollRailLabel');
  function updateRail(slideIdx, slide) {
    const totalSlides = MAIN_COUNT + 4;
    const cur = stepState.get(slide) || 1;
    const total = Math.max(1, maxSteps(slide));
    const frac = (slideIdx + cur / total) / totalSlides;
    if (railFill) railFill.style.height = (frac * 100).toFixed(1) + '%';
    if (railLabel) {
      const label = slideIdx < MAIN_COUNT
        ? `${String(slideIdx + 1).padStart(2,'0')} / ${MAIN_COUNT}`
        : `Q&A · ${slideIdx - MAIN_COUNT + 1} / 4`;
      railLabel.textContent = label;
    }
  }
  document.addEventListener('slidechange', (e) => {
    const idx = e.detail.index;
    const slide = e.detail.slide;
    const prevSlide = e.detail.previousSlide;

    if (prevSlide) {
      prevSlide.classList.add('exiting');
      setTimeout(() => prevSlide.classList.remove('exiting'), 1200);
    }

    if (lastActive) {
      lastActive.removeAttribute('data-active');
    }
    slides.forEach(s => {
      if (s !== slide) s.removeAttribute('data-active');
    });
    slide.setAttribute('data-active', 'true');
    lastActive = slide;
    if (!stepState.has(slide)) resetSlide(slide);
    applyStepCount(slide, stepState.get(slide) || 0);
    updateRail(idx, slide);
    triggerSlideAnim(idx, slide);
  });

  // initial state — slide 0 active
  setTimeout(() => {
    const init = deck.querySelector('section');
    if (init) {
      init.setAttribute('data-active', 'true');
      lastActive = init;
      resetSlide(init);
      triggerSlideAnim(0, init);
    }
  }, 80);

  // ---------- animations per slide ----------
  function triggerSlideAnim(idx, slide) {
    const label = slide.dataset.label;
    if (label === 'Cover') drawCoverNet();
    if (label === 'Network anim') runNetworkAnim(0, 0);
    if (label === 'Absorption ratio') drawAbsorptionChart();
    if (label === 'SHAP') runShap();
    if (label === 'Herding CCK') drawCCK();
    if (label === 'Spillover') drawSpillover();
    if (label === 'Contagion') runContagion();
    if (label === 'Trading') drawEquity();
    if (label === 'Headline') runShap(); // no-op safe
  }

  // ===== Cover network — sparse decorative =====
  function drawCoverNet() {
    const c = document.getElementById('coverNet');
    if (!c) return;
    const ctx = c.getContext('2d');
    const W = c.width, H = c.height;
    ctx.clearRect(0, 0, W, H);
    const N = 64;
    const seed = (s) => () => (s = (s * 9301 + 49297) % 233280) / 233280;
    const rnd = seed(7);
    const pts = Array.from({length: N}, () => ({
      x: rnd() * W * 0.95,
      y: rnd() * H,
      r: 1.5 + rnd() * 2.5,
    }));
    // edges by proximity
    const edges = [];
    for (let i = 0; i < N; i++) for (let j = i + 1; j < N; j++) {
      const dx = pts[i].x - pts[j].x, dy = pts[i].y - pts[j].y;
      const d = Math.hypot(dx, dy);
      if (d < 220) edges.push([i, j, 1 - d / 220]);
    }
    edges.forEach(([i, j, w]) => {
      ctx.strokeStyle = `oklch(0.78 0.12 220 / ${0.06 + w * 0.18})`;
      ctx.lineWidth = 0.6;
      ctx.beginPath();
      ctx.moveTo(pts[i].x, pts[i].y);
      ctx.lineTo(pts[j].x, pts[j].y);
      ctx.stroke();
    });
    pts.forEach(p => {
      ctx.fillStyle = `oklch(0.78 0.12 220 / 0.85)`;
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
      ctx.fill();
    });
  }

  // ===== Network calm → crisis =====
  let netNodes = null, netRaf = null, netRegime = 0; // 0 calm, 1 crisis
  function buildNetworkNodes() {
    const c = document.getElementById('netCanvas');
    if (!c) return null;
    const W = c.width, H = c.height;
    const sectors = 7;
    const perSec = 20;
    const N = sectors * perSec;
    const sectorColors = [
      'oklch(0.78 0.12 220)', // cyan
      'oklch(0.78 0.13 70)',  // amber
      'oklch(0.72 0.12 155)', // green
      'oklch(0.7 0.14 300)',  // violet
      'oklch(0.68 0.16 28)',  // red
      'oklch(0.72 0.1 200)',
      'oklch(0.74 0.09 110)',
    ];
    const nodes = [];
    let seed = 13;
    const rnd = () => (seed = (seed * 9301 + 49297) % 233280) / 233280;
    for (let s = 0; s < sectors; s++) {
      const cx = W/2 + Math.cos(s / sectors * Math.PI * 2) * W * 0.35;
      const cy = H/2 + Math.sin(s / sectors * Math.PI * 2) * H * 0.35;
      for (let k = 0; k < perSec; k++) {
        nodes.push({
          sector: s,
          color: sectorColors[s],
          // calm position — organized sector clusters
          calmX: cx + (rnd() - 0.5) * 140,
          calmY: cy + (rnd() - 0.5) * 140,
          // crisis — everything collapses toward center (condensato) but stays visible
          crisisX: W/2 + (rnd() - 0.5) * 650,
          crisisY: H/2 + (rnd() - 0.5) * 650,
          x: 0, y: 0,
        });
      }
    }
    return nodes;
  }

  function runNetworkAnim(targetRegime, customDur) {
    const c = document.getElementById('netCanvas');
    if (!c) return;
    if (!netNodes) netNodes = buildNetworkNodes();
    if (netRaf) cancelAnimationFrame(netRaf);
    const ctx = c.getContext('2d');
    const W = c.width, H = c.height;
    const stage = document.getElementById('netStage');
    const label = document.getElementById('netLabel');
    const scrub = document.getElementById('netScrub');
    const stats = document.querySelectorAll('#netStats .v');

    const fromRegime = netRegime;
    const toRegime = (targetRegime !== undefined) ? targetRegime : 1 - netRegime;
    netRegime = toRegime;

    if (toRegime === 1) {
      label.textContent = 'Crisis regime · COVID-19 · Mar 2020';
      stage.style.borderColor = 'var(--amber)';
    } else {
      label.textContent = 'Calm regime · Q3 2019';
      stage.style.borderColor = 'var(--line-2)';
    }

    const dur = customDur !== undefined ? customDur : 4000;
    const start = performance.now();

    function drawFrame(alpha) {
      // node positions interp
      netNodes.forEach(n => {
        n.x = n.calmX * (1 - alpha) + n.crisisX * alpha;
        n.y = n.calmY * (1 - alpha) + n.crisisY * alpha;
      });
      // density: in calm, edges only within sector mostly; in crisis, almost all
      ctx.clearRect(0, 0, W, H);
      
      // glow background
      const grd = ctx.createRadialGradient(W/2, H/2, 0, W/2, H/2, W/2);
      grd.addColorStop(0, alpha > 0.5 ? 'oklch(0.78 0.2 70 / 0.12)' : 'oklch(0.78 0.18 220 / 0.08)');
      grd.addColorStop(1, 'transparent');
      ctx.fillStyle = grd;
      ctx.fillRect(0,0,W,H);

      // edges
      const N = netNodes.length;
      const sameSecP = 0.5 + 0.5 * (1 - alpha);
      const crossSecP = 0.02 + 0.6 * alpha;
      for (let i = 0; i < N; i++) {
        for (let j = i + 1; j < N; j++) {
          const a = netNodes[i], b = netNodes[j];
          const same = a.sector === b.sector;
          const seedVal = (i * 73856093 ^ j * 19349663) >>> 0;
          const r = (seedVal % 10000) / 10000;
          const p = same ? sameSecP : crossSecP;
          if (r < p) {
            const op = same ? 0.15 + 0.25 * alpha : 0.04 + 0.22 * alpha;
            ctx.strokeStyle = same ? a.color.replace(')', ` / ${op})`) : `oklch(0.78 0.12 220 / ${op})`;
            ctx.lineWidth = 0.5 + 1.0 * alpha;
            ctx.beginPath();
            ctx.moveTo(a.x, a.y);
            ctx.lineTo(b.x, b.y);
            ctx.stroke();
          }
        }
      }
      // nodes
      netNodes.forEach(n => {
        ctx.fillStyle = n.color;
        ctx.shadowBlur = 5 * alpha;
        ctx.shadowColor = n.color;
        ctx.beginPath();
        ctx.arc(n.x, n.y, 4 + 2 * alpha, 0, Math.PI * 2);
        ctx.fill();
        ctx.shadowBlur = 0;
      });

      // update meta
      const ar = (0.23 * (1 - alpha) + 0.65 * alpha).toFixed(2);
      const den = (0.82 * (1 - alpha) + 1.00 * alpha).toFixed(2);
      if (stats.length >= 2) {
        stats[0].textContent = ar;
        stats[1].textContent = den;
        stats[0].parentElement.classList.toggle('crisis', alpha > 0.5);
        stats[1].parentElement.classList.toggle('crisis', alpha > 0.5);
      }
      stage.dataset.regime = alpha > 0.5 ? 'crisis' : 'calm';
      scrub.style.width = `${(alpha * 100).toFixed(1)}%`;
    }

    if (dur === 0) {
      drawFrame(toRegime);
      return;
    }

    function frame(now) {
      const t = Math.min(1, (now - start) / dur);
      // exponential out for a snappy feel
      const e = t === 1 ? 1 : 1 - Math.pow(2, -10 * t);
      const alpha = fromRegime + (toRegime - fromRegime) * e;

      // add a subtle "impact shake" when shifting to crisis
      if (toRegime === 1 && t > 0.05 && t < 0.4) {
        const shake = (1 - t / 0.4) * 4;
        stage.style.transform = `translate(${(Math.random()-0.5)*shake}px, ${(Math.random()-0.5)*shake}px)`;
      } else {
        stage.style.transform = '';
      }

      drawFrame(alpha);

      if (t < 1) netRaf = requestAnimationFrame(frame);
    }
    netRaf = requestAnimationFrame(frame);
  }

  document.addEventListener('click', (e) => {
    if (e.target && e.target.id === 'netToggle') runNetworkAnim();
    if (e.target && e.target.id === 'contagionReplay') runContagion();
  });

  // ===== Absorption ratio chart =====
  function drawAbsorptionChart() {
    const svg = document.getElementById('arChart');
    if (!svg) return;
    svg.innerHTML = '';
    const W = 1000, H = 560;
    const padL = 60, padR = 30, padT = 30, padB = 80;

    // Synth data: monthly AR 2013–2025, with spikes at crises
    const months = [];
    for (let y = 2013; y <= 2025; y++) for (let m = 0; m < 12; m++) months.push({ y, m });
    const events = [
      { y: 2015, m: 7, mag: 0.18 },  // China shock
      { y: 2018, m: 1, mag: 0.16 },  // Volmageddon
      { y: 2018, m: 11, mag: 0.14 },
      { y: 2020, m: 2, mag: 0.42 },  // COVID
      { y: 2022, m: 5, mag: 0.20 },  // bear
      { y: 2023, m: 2, mag: 0.18 },  // SVB
      { y: 2024, m: 7, mag: 0.16 },  // Japan carry
    ];
    const data = months.map((mo, i) => {
      let v = 0.45 + 0.05 * Math.sin(i * 0.31) + 0.04 * Math.cos(i * 0.17);
      events.forEach(ev => {
        const di = (ev.y - 2013) * 12 + ev.m;
        const dist = Math.abs(i - di);
        if (dist < 8) v += ev.mag * Math.exp(-dist * dist / 8);
      });
      return { i, v: Math.min(0.95, v) };
    });

    const x = (i) => padL + (i / (data.length - 1)) * (W - padL - padR);
    const yMin = 0.3, yMax = 1.0;
    const y = (v) => padT + (1 - (v - yMin) / (yMax - yMin)) * (H - padT - padB);

    // grid
    const ns = 'http://www.w3.org/2000/svg';
    for (let g = 0.4; g <= 0.9; g += 0.1) {
      const ln = document.createElementNS(ns, 'line');
      ln.setAttribute('x1', padL); ln.setAttribute('x2', W - padR);
      ln.setAttribute('y1', y(g)); ln.setAttribute('y2', y(g));
      ln.setAttribute('stroke', 'rgba(232,234,240,0.06)');
      ln.setAttribute('stroke-width', 1);
      svg.appendChild(ln);
      const tx = document.createElementNS(ns, 'text');
      tx.setAttribute('x', padL - 12); tx.setAttribute('y', y(g) + 4);
      tx.setAttribute('text-anchor', 'end');
      tx.setAttribute('fill', 'rgba(166,171,184,0.7)');
      tx.setAttribute('font-family', 'JetBrains Mono');
      tx.setAttribute('font-size', 12);
      tx.textContent = g.toFixed(1);
      svg.appendChild(tx);
    }

    // x-axis years
    [2014, 2016, 2018, 2020, 2022, 2024].forEach(yr => {
      const i = (yr - 2013) * 12;
      const tx = document.createElementNS(ns, 'text');
      tx.setAttribute('x', x(i));
      tx.setAttribute('y', H - padB + 30);
      tx.setAttribute('text-anchor', 'middle');
      tx.setAttribute('fill', 'rgba(166,171,184,0.7)');
      tx.setAttribute('font-family', 'JetBrains Mono');
      tx.setAttribute('font-size', 12);
      tx.textContent = yr;
      svg.appendChild(tx);
    });

    // path
    const path = document.createElementNS(ns, 'path');
    let d = '';
    data.forEach((p, k) => { d += (k === 0 ? 'M' : 'L') + x(p.i) + ',' + y(p.v); });
    path.setAttribute('d', d);
    path.setAttribute('fill', 'none');
    path.setAttribute('stroke', 'oklch(0.78 0.12 220)');
    path.setAttribute('stroke-width', 2);
    path.setAttribute('stroke-linejoin', 'round');
    path.setAttribute('stroke-linecap', 'round');
    const len = path.getTotalLength ? path.getTotalLength() : 4000;
    path.setAttribute('stroke-dasharray', len);
    path.setAttribute('stroke-dashoffset', len);
    svg.appendChild(path);
    requestAnimationFrame(() => {
      path.style.transition = 'stroke-dashoffset 2200ms cubic-bezier(0.2, 0.7, 0.2, 1)';
      path.setAttribute('stroke-dashoffset', 0);
    });

    // crisis markers, fade in staggered
    const labels = [
      { y: 2018, m: 1, t: 'Volmag.' },
      { y: 2020, m: 2, t: 'COVID-19' },
      { y: 2022, m: 5, t: 'Bear 22' },
      { y: 2023, m: 2, t: 'SVB' },
      { y: 2024, m: 7, t: 'JP carry' },
    ];
    labels.forEach((l, k) => {
      const i = (l.y - 2013) * 12 + l.m;
      const v = data[i].v;
      const cx = x(i), cy = y(v);
      const cir = document.createElementNS(ns, 'circle');
      cir.setAttribute('cx', cx); cir.setAttribute('cy', cy);
      cir.setAttribute('r', 5);
      cir.setAttribute('fill', 'oklch(0.78 0.13 70)');
      cir.setAttribute('opacity', 0);
      svg.appendChild(cir);
      const t = document.createElementNS(ns, 'text');
      t.setAttribute('x', cx);
      t.setAttribute('y', cy - 14);
      t.setAttribute('text-anchor', 'middle');
      t.setAttribute('fill', 'oklch(0.78 0.13 70)');
      t.setAttribute('font-family', 'JetBrains Mono');
      t.setAttribute('font-size', 12);
      t.setAttribute('opacity', 0);
      t.textContent = l.t;
      svg.appendChild(t);
      setTimeout(() => {
        cir.style.transition = 'opacity 400ms';
        t.style.transition = 'opacity 400ms';
        cir.setAttribute('opacity', 1);
        t.setAttribute('opacity', 1);
      }, 1800 + k * 220);
    });

    // axis title
    const yt = document.createElementNS(ns, 'text');
    yt.setAttribute('x', padL); yt.setAttribute('y', padT - 8);
    yt.setAttribute('fill', 'rgba(166,171,184,0.9)');
    yt.setAttribute('font-family', 'JetBrains Mono');
    yt.setAttribute('font-size', 12);
    yt.setAttribute('letter-spacing', '0.16em');
    yt.textContent = 'AR · TOP 20% EIGENVALUES / TOTAL';
    svg.appendChild(yt);
  }

  // ===== SHAP =====
  function runShap() {
    const stage = document.getElementById('shapStage');
    if (!stage) return;
    const rows = stage.querySelectorAll('.shap-row');
    rows.forEach((r, i) => {
      const w = parseFloat(r.dataset.w);
      const fill = r.querySelector('.bar-fill');
      fill.style.width = '0%';
      setTimeout(() => { fill.style.width = w + '%'; }, 200 + i * 90);
    });
  }

  // ===== CCK scatter =====
  function drawCCK() {
    const svg = document.getElementById('cckPlot');
    if (!svg) return;
    svg.innerHTML = '';
    const ns = 'http://www.w3.org/2000/svg';
    const W = 800, H = 500;
    const padL = 60, padR = 20, padT = 30, padB = 50;

    // axes
    const ax = (x1, y1, x2, y2) => {
      const l = document.createElementNS(ns, 'line');
      l.setAttribute('x1', x1); l.setAttribute('y1', y1);
      l.setAttribute('x2', x2); l.setAttribute('y2', y2);
      l.setAttribute('stroke', 'rgba(232,234,240,0.18)');
      l.setAttribute('stroke-width', 1);
      svg.appendChild(l);
    };
    ax(padL, H - padB, W - padR, H - padB);
    ax(padL, padT, padL, H - padB);

    // labels
    const labx = document.createElementNS(ns, 'text');
    labx.setAttribute('x', (W) / 2); labx.setAttribute('y', H - 10);
    labx.setAttribute('text-anchor', 'middle');
    labx.setAttribute('fill', 'rgba(166,171,184,0.8)');
    labx.setAttribute('font-family', 'JetBrains Mono');
    labx.setAttribute('font-size', 12);
    labx.textContent = 'R²ₘ  · squared market return';
    svg.appendChild(labx);

    const laby = document.createElementNS(ns, 'text');
    laby.setAttribute('x', 18); laby.setAttribute('y', H/2);
    laby.setAttribute('fill', 'rgba(166,171,184,0.8)');
    laby.setAttribute('font-family', 'JetBrains Mono');
    laby.setAttribute('font-size', 12);
    laby.setAttribute('transform', `rotate(-90 18 ${H/2})`);
    laby.setAttribute('text-anchor', 'middle');
    laby.textContent = 'CSAD · cross-sectional dispersion';
    svg.appendChild(laby);

    // scatter — gradual: positive slope; shock: negative slope
    const xMax = 0.0025, yMax = 0.04;
    const xs = (v) => padL + (v / xMax) * (W - padL - padR);
    const ys = (v) => H - padB - (v / yMax) * (H - padT - padB);

    let seed = 91;
    const rnd = () => (seed = (seed*9301+49297) % 233280) / 233280;

    function addPoint(x, y, color, delay) {
      const c = document.createElementNS(ns, 'circle');
      c.setAttribute('cx', xs(x)); c.setAttribute('cy', ys(y));
      c.setAttribute('r', 3.5);
      c.setAttribute('fill', color);
      c.setAttribute('opacity', 0);
      svg.appendChild(c);
      setTimeout(() => {
        c.style.transition = 'opacity 300ms';
        c.setAttribute('opacity', 0.85);
      }, delay);
    }

    // Gradual decline points (cyan, positive slope)
    for (let i = 0; i < 100; i++) {
      const xv = rnd() * xMax;
      const yv = 0.012 + xv * 8 + (rnd() - 0.5) * 0.006;
      addPoint(xv, Math.max(0.005, Math.min(yMax * 0.95, yv)), 'oklch(0.78 0.12 220 / 0.9)', 200 + i * 8);
    }
    // Shock points (amber, negative slope — herding)
    for (let i = 0; i < 60; i++) {
      const xv = 0.0008 + rnd() * (xMax - 0.0008);
      const yv = 0.028 - xv * 6 + (rnd() - 0.5) * 0.005;
      addPoint(xv, Math.max(0.005, Math.min(yMax * 0.95, yv)), 'oklch(0.78 0.13 70 / 0.95)', 1200 + i * 14);
    }

    // trend lines
    setTimeout(() => {
      const grad = document.createElementNS(ns, 'line');
      grad.setAttribute('x1', xs(0)); grad.setAttribute('y1', ys(0.012));
      grad.setAttribute('x2', xs(xMax)); grad.setAttribute('y2', ys(0.012 + xMax * 8));
      grad.setAttribute('stroke', 'oklch(0.78 0.12 220)');
      grad.setAttribute('stroke-width', 2);
      grad.setAttribute('stroke-dasharray', '4 4');
      grad.setAttribute('opacity', 0);
      svg.appendChild(grad);
      grad.style.transition = 'opacity 600ms';
      requestAnimationFrame(() => grad.setAttribute('opacity', 0.9));

      const lab1 = document.createElementNS(ns, 'text');
      lab1.setAttribute('x', xs(xMax) - 8); lab1.setAttribute('y', ys(0.012 + xMax * 8) - 8);
      lab1.setAttribute('text-anchor', 'end');
      lab1.setAttribute('fill', 'oklch(0.78 0.12 220)');
      lab1.setAttribute('font-family', 'JetBrains Mono');
      lab1.setAttribute('font-size', 12);
      lab1.textContent = 'Gradual · γ₂ > 0';
      lab1.setAttribute('opacity', 0);
      svg.appendChild(lab1);
      lab1.style.transition = 'opacity 600ms';
      setTimeout(() => lab1.setAttribute('opacity', 1), 80);
    }, 1100);

    setTimeout(() => {
      const sh = document.createElementNS(ns, 'line');
      sh.setAttribute('x1', xs(0)); sh.setAttribute('y1', ys(0.028));
      sh.setAttribute('x2', xs(xMax)); sh.setAttribute('y2', ys(0.028 - xMax * 6));
      sh.setAttribute('stroke', 'oklch(0.78 0.13 70)');
      sh.setAttribute('stroke-width', 2);
      sh.setAttribute('stroke-dasharray', '4 4');
      sh.setAttribute('opacity', 0);
      svg.appendChild(sh);
      sh.style.transition = 'opacity 600ms';
      requestAnimationFrame(() => sh.setAttribute('opacity', 0.95));

      const lab2 = document.createElementNS(ns, 'text');
      lab2.setAttribute('x', xs(xMax) - 8); lab2.setAttribute('y', ys(0.028 - xMax * 6) + 18);
      lab2.setAttribute('text-anchor', 'end');
      lab2.setAttribute('fill', 'oklch(0.78 0.13 70)');
      lab2.setAttribute('font-family', 'JetBrains Mono');
      lab2.setAttribute('font-size', 12);
      lab2.textContent = 'Shock · γ₂ < 0  ⇒ herding';
      lab2.setAttribute('opacity', 0);
      svg.appendChild(lab2);
      lab2.style.transition = 'opacity 600ms';
      setTimeout(() => lab2.setAttribute('opacity', 1), 80);
    }, 2300);
  }

  // ===== Spillover heatmap =====
  function drawSpillover() {
    const wrap = document.getElementById('spillHeatmap');
    if (!wrap) return;
    wrap.innerHTML = '';
    const sectors = ['Indust', 'Fin', 'Tech', 'Disc', 'Comm', 'Energ', 'Mater', 'Health', 'Stapl', 'RE', 'Util'];
    // synthetic spillover matrix (row → col)
    // transmitters first (Industrials, Financials, Tech)
    const matrix = [];
    const transmitters = [0, 1, 2]; // strong out
    const receivers = [8, 10, 7]; // strong in
    for (let i = 0; i < 11; i++) {
      const row = [];
      for (let j = 0; j < 11; j++) {
        if (i === j) { row.push(0); continue; }
        let v = 4 + ((i * 7 + j * 3) % 5);
        if (transmitters.includes(i)) v += 5 + ((j * 11) % 4);
        if (receivers.includes(j)) v += 4 + ((i * 5) % 3);
        if (transmitters.includes(j)) v -= 2;
        v = Math.max(1, Math.min(18, v));
        row.push(v);
      }
      matrix.push(row);
    }
    const max = 18, min = 1;

    // grid: row labels + heatmap + col labels
    wrap.style.display = 'grid';
    wrap.style.gridTemplateColumns = '70px 1fr';
    wrap.style.gridTemplateRows = '1fr 50px';
    wrap.style.gap = '4px';
    wrap.style.flex = '1';
    wrap.style.minHeight = '0';

    const rowLabels = document.createElement('div');
    rowLabels.style.cssText = 'display: flex; flex-direction: column; gap: 2px; justify-content: stretch; align-items: flex-end; padding-right: 6px;';
    sectors.forEach(s => {
      const d = document.createElement('div');
      d.textContent = s;
      d.style.cssText = 'flex:1; display:flex; align-items:center; font-family: JetBrains Mono; font-size: 11px; color: var(--ink-3); letter-spacing: 0.06em;';
      rowLabels.appendChild(d);
    });
    wrap.appendChild(rowLabels);

    const heat = document.createElement('div');
    heat.style.cssText = 'display: grid; grid-template-columns: repeat(11, 1fr); grid-template-rows: repeat(11, 1fr); gap: 2px;';
    const cells = [];
    for (let i = 0; i < 11; i++) {
      for (let j = 0; j < 11; j++) {
        const c = document.createElement('div');
        c.style.cssText = 'background: rgba(232,234,240,0.04); border-radius: 2px; transition: background 700ms ease;';
        heat.appendChild(c);
        cells.push({ el: c, i, j });
      }
    }
    wrap.appendChild(heat);

    const corner = document.createElement('div'); wrap.appendChild(corner);

    const colLabels = document.createElement('div');
    colLabels.style.cssText = 'display: grid; grid-template-columns: repeat(11, 1fr); gap: 2px; padding-top: 6px;';
    sectors.forEach(s => {
      const d = document.createElement('div');
      d.textContent = s;
      d.style.cssText = 'font-family: JetBrains Mono; font-size: 11px; color: var(--ink-3); letter-spacing: 0.06em; text-align: center; transform: rotate(0deg);';
      colLabels.appendChild(d);
    });
    wrap.appendChild(colLabels);

    // animate fill diagonal-wise
    cells.forEach(({el, i, j}, k) => {
      const v = matrix[i][j];
      const t = (v - min) / (max - min);
      // amber tones for transmitters' rows, cyan for receivers' cols overlay
      const isTrans = transmitters.includes(i);
      const hue = isTrans ? 70 : 220;
      const chr = 0.13 * t;
      const lum = 0.25 + t * 0.45;
      const op = 0.18 + t * 0.78;
      const order = (i + j); // wave from corner
      setTimeout(() => {
        el.style.background = `oklch(${lum} ${chr} ${hue} / ${op})`;
      }, 150 + order * 90);
    });
  }

  // ===== Contagion cascade =====
  let contState = null;
  function buildContagionGraph() {
    const c = document.getElementById('contCanvas');
    const W = c.width, H = c.height;
    let seed = 41;
    const rnd = () => (seed = (seed*9301+49297) % 233280) / 233280;
    const N = 110;
    const nodes = [];
    for (let i = 0; i < N; i++) {
      const r = 30 + rnd() * (Math.min(W, H) * 0.42);
      const ang = rnd() * Math.PI * 2;
      nodes.push({
        x: W/2 + Math.cos(ang) * r,
        y: H/2 + Math.sin(ang) * r,
        state: 'healthy',
        infectAt: -1,
      });
    }
    // nearest-neighbor edges (k = 4)
    const edges = [];
    for (let i = 0; i < N; i++) {
      const dists = [];
      for (let j = 0; j < N; j++) if (j !== i) dists.push({ j, d: Math.hypot(nodes[i].x - nodes[j].x, nodes[i].y - nodes[j].y) });
      dists.sort((a, b) => a.d - b.d);
      for (let k = 0; k < 4; k++) {
        const j = dists[k].j;
        if (j > i) edges.push([i, j]);
      }
    }
    // pick a hub-like origin near center
    nodes.sort((a, b) => Math.hypot(a.x - W/2, a.y - H/2) - Math.hypot(b.x - W/2, b.y - H/2));
    return { nodes, edges, origin: 0 };
  }

  function runContagion() {
    const c = document.getElementById('contCanvas');
    if (!c) return;
    const ctx = c.getContext('2d');
    const W = c.width, H = c.height;
    contState = buildContagionGraph();
    const { nodes, edges, origin } = contState;

    // build adjacency
    const adj = new Map();
    edges.forEach(([a, b]) => {
      if (!adj.has(a)) adj.set(a, []);
      if (!adj.has(b)) adj.set(b, []);
      adj.get(a).push(b);
      adj.get(b).push(a);
    });

    nodes.forEach(n => { n.state = 'healthy'; n.infectAt = -1; });
    nodes[origin].state = 'origin';
    nodes[origin].infectAt = 0;

    // BFS schedule
    const queue = [origin];
    const visited = new Set([origin]);
    let step = 1;
    while (queue.length) {
      const next = [];
      for (const v of queue) {
        const ns = adj.get(v) || [];
        for (const u of ns) {
          if (!visited.has(u)) {
            visited.add(u);
            nodes[u].infectAt = step * 220;
            nodes[u].state = 'failed';
            next.push(u);
          }
        }
      }
      queue.length = 0;
      queue.push(...next);
      step++;
    }

    const start = performance.now();
    const stage = document.getElementById('contStage');

    function frame(now) {
      const t = now - start;
      ctx.clearRect(0, 0, W, H);

      // radial gradient glow behind cascade
      const grd = ctx.createRadialGradient(nodes[origin].x, nodes[origin].y, 0, nodes[origin].x, nodes[origin].y, Math.min(W,H)*0.6);
      grd.addColorStop(0, 'oklch(0.62 0.18 28 / 0.08)');
      grd.addColorStop(1, 'transparent');
      ctx.fillStyle = grd;
      ctx.fillRect(0,0,W,H);

      // screen shake logic
      let shakeX = 0, shakeY = 0;

      // edges
      edges.forEach(([a, b]) => {
        const A = nodes[a], B = nodes[b];
        const both = (A.infectAt >= 0 && t > A.infectAt) && (B.infectAt >= 0 && t > B.infectAt);
        const op = both ? 0.5 : 0.1;
        const col = both ? 'oklch(0.62 0.18 28 / OP)' : 'oklch(0.5 0.04 220 / OP)';
        ctx.strokeStyle = col.replace('OP', op);
        ctx.lineWidth = both ? 1.5 : 0.6;
        ctx.beginPath();
        ctx.moveTo(A.x, A.y);
        ctx.lineTo(B.x, B.y);
        ctx.stroke();
      });
      // nodes
      nodes.forEach((n, i) => {
        let color;
        const active = n.infectAt > 0 && t > n.infectAt;
        const justInfected = active && (t - n.infectAt < 600);

        if (justInfected) {
          const intensity = 1 - (t - n.infectAt) / 600;
          shakeX += (Math.random()-0.5) * 1.5 * intensity;
          shakeY += (Math.random()-0.5) * 1.5 * intensity;
        }

        if (n.state === 'healthy' || (n.infectAt > 0 && t < n.infectAt)) {
          color = 'oklch(0.5 0.08 220 / 0.7)';
          ctx.fillStyle = color;
          ctx.beginPath(); ctx.arc(n.x, n.y, 3, 0, Math.PI * 2); ctx.fill();
        } else if (i === origin) {
          const pulse = 0.7 + 0.3 * Math.sin(t / 200);
          ctx.fillStyle = `oklch(0.62 0.18 28 / ${pulse})`;
          ctx.beginPath(); ctx.arc(n.x, n.y, 10, 0, Math.PI * 2); ctx.fill();
          ctx.strokeStyle = `oklch(0.62 0.18 28 / 0.4)`;
          ctx.lineWidth = 2;
          ctx.beginPath(); ctx.arc(n.x, n.y, 10 + 12 * (1 - pulse), 0, Math.PI * 2); ctx.stroke();
        } else {
          const since = t - n.infectAt;
          const flash = Math.max(0, 1 - since / 800);
          const r = 4 + flash * 6;
          ctx.shadowBlur = 15 * flash;
          ctx.shadowColor = 'oklch(0.62 0.18 28)';
          ctx.fillStyle = `oklch(0.62 0.18 28 / ${0.8 + 0.2 * flash})`;
          ctx.beginPath(); ctx.arc(n.x, n.y, r, 0, Math.PI * 2); ctx.fill();
          ctx.shadowBlur = 0;
        }
      });

      if (stage) stage.style.transform = `translate(${shakeX}px, ${shakeY}px)`;

      if (t < 9000) requestAnimationFrame(frame);
      else if (stage) stage.style.transform = '';
    }
    requestAnimationFrame(frame);
  }

  // ===== Equity curve =====
  function drawEquity() {
    const svg = document.getElementById('eqChart');
    if (!svg) return;
    svg.innerHTML = '';
    const ns = 'http://www.w3.org/2000/svg';
    const W = 1000, H = 600;
    const padL = 60, padR = 30, padT = 40, padB = 70;
    const nMonths = 150; // 12.5 years × 12

    // Build buy-and-hold and strategy series with crisis drawdowns
    let seed = 17;
    const rnd = () => (seed = (seed*9301+49297) % 233280) / 233280;

    const events = [
      { i: 24, mag: -0.06 }, // 2015 China
      { i: 60, mag: -0.10 }, // 2018 Q4
      { i: 86, mag: -0.32 }, // 2020 COVID
      { i: 110, mag: -0.22 }, // 2022 bear
      { i: 122, mag: -0.08 }, // 2023 SVB
      { i: 138, mag: -0.10 }, // 2024 Japan
    ];

    const bh = [1];
    for (let i = 1; i < nMonths; i++) {
      let r = 0.0085 + (rnd() - 0.5) * 0.025;
      events.forEach(ev => {
        if (i >= ev.i && i < ev.i + 3) r += ev.mag / 3;
        if (i >= ev.i + 3 && i < ev.i + 9) r += -ev.mag / 8;
      });
      bh.push(bh[i-1] * (1 + r));
    }
    // strategy: same returns when "risk-on", reduced exposure during a window before/around crises
    const strat = [1];
    for (let i = 1; i < nMonths; i++) {
      const bhRet = bh[i] / bh[i-1] - 1;
      let exposure = 1;
      events.forEach(ev => {
        if (i >= ev.i - 2 && i < ev.i + 4) exposure = 0.05; // de-risk
        else if (i >= ev.i + 4 && i < ev.i + 8) exposure = 0.55; // re-enter slowly
      });
      let r = bhRet * exposure + (1 - exposure) * 0.0017; // RF when out
      r -= 0.0006; // tx cost drag avg
      strat.push(strat[i-1] * (1 + r));
    }

    const maxV = Math.max(Math.max(...bh), Math.max(...strat)) * 1.05;
    const minV = 0.7;

    const x = (i) => padL + (i / (nMonths - 1)) * (W - padL - padR);
    const y = (v) => padT + (1 - (v - minV) / (maxV - minV)) * (H - padT - padB);

    // gridlines
    for (let g = 1; g <= 3; g += 0.5) {
      const ln = document.createElementNS(ns, 'line');
      ln.setAttribute('x1', padL); ln.setAttribute('x2', W - padR);
      ln.setAttribute('y1', y(g)); ln.setAttribute('y2', y(g));
      ln.setAttribute('stroke', 'rgba(232,234,240,0.06)');
      svg.appendChild(ln);
      const t = document.createElementNS(ns, 'text');
      t.setAttribute('x', padL - 12); t.setAttribute('y', y(g) + 4);
      t.setAttribute('text-anchor', 'end');
      t.setAttribute('fill', 'rgba(166,171,184,0.7)');
      t.setAttribute('font-family', 'JetBrains Mono');
      t.setAttribute('font-size', 12);
      t.textContent = g.toFixed(1) + 'x';
      svg.appendChild(t);
    }
    [2014, 2017, 2020, 2023, 2025].forEach(yr => {
      const i = (yr - 2013) * 12;
      if (i > nMonths) return;
      const t = document.createElementNS(ns, 'text');
      t.setAttribute('x', x(i)); t.setAttribute('y', H - padB + 28);
      t.setAttribute('text-anchor', 'middle');
      t.setAttribute('fill', 'rgba(166,171,184,0.7)');
      t.setAttribute('font-family', 'JetBrains Mono');
      t.setAttribute('font-size', 12);
      t.textContent = yr;
      svg.appendChild(t);
    });

    function drawPath(series, color, dash, delay) {
      const p = document.createElementNS(ns, 'path');
      let d = '';
      series.forEach((v, i) => { d += (i === 0 ? 'M' : 'L') + x(i) + ',' + y(v); });
      p.setAttribute('d', d);
      p.setAttribute('fill', 'none');
      p.setAttribute('stroke', color);
      p.setAttribute('stroke-width', 2.4);
      p.setAttribute('stroke-linejoin', 'round');
      if (dash) p.setAttribute('stroke-dasharray', dash);
      const len = 4500;
      p.setAttribute('stroke-dasharray', dash ? dash : len);
      p.setAttribute('stroke-dashoffset', dash ? 0 : len);
      svg.appendChild(p);
      setTimeout(() => {
        if (!dash) {
          p.style.transition = 'stroke-dashoffset 2400ms cubic-bezier(0.2, 0.7, 0.2, 1)';
          p.setAttribute('stroke-dashoffset', 0);
        }
      }, delay);
      return p;
    }

    drawPath(bh, 'oklch(0.78 0.13 70)', null, 200);
    drawPath(strat, 'oklch(0.78 0.12 220)', null, 600);

    // legend
    const lg = (txt, color, yo) => {
      const c = document.createElementNS(ns, 'rect');
      c.setAttribute('x', W - padR - 220); c.setAttribute('y', yo);
      c.setAttribute('width', 14); c.setAttribute('height', 3);
      c.setAttribute('fill', color);
      svg.appendChild(c);
      const t = document.createElementNS(ns, 'text');
      t.setAttribute('x', W - padR - 200); t.setAttribute('y', yo + 6);
      t.setAttribute('fill', 'rgba(232,234,240,0.9)');
      t.setAttribute('font-family', 'JetBrains Mono');
      t.setAttribute('font-size', 13);
      t.textContent = txt;
      svg.appendChild(t);
    };
    lg('GraphSAGE + Trend · Sharpe 0.79', 'oklch(0.78 0.12 220)', padT + 4);
    lg('Buy & Hold · Sharpe 0.46', 'oklch(0.78 0.13 70)', padT + 28);

    // crisis bands
    events.forEach(ev => {
      const r = document.createElementNS(ns, 'rect');
      r.setAttribute('x', x(ev.i));
      r.setAttribute('y', padT);
      r.setAttribute('width', x(ev.i + 4) - x(ev.i));
      r.setAttribute('height', H - padT - padB);
      r.setAttribute('fill', 'oklch(0.78 0.13 70 / 0.07)');
      svg.appendChild(r);
    });
  }

})();
